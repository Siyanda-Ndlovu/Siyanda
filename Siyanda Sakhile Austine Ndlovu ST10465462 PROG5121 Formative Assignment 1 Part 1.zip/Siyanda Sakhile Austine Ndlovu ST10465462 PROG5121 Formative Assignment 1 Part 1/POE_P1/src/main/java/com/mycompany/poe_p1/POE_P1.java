/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.poe_p1;

import java.util.Scanner;

/**
 *
 * @author Siyanda
 */
public class POE_P1 {

    public static void main(String[] args) {
        Login myObj = new Login();     //creating a Login class
        Scanner scan = new Scanner(System.in);    //creating a scanner
        
        String username;  //declaring username and password
        String password;
        
        System.out.println("=====User registration=====");
        
        
        //Registering a user
        System.out.print("Enter Your First Name: ");
        String firstName = scan.nextLine();
        myObj.registerUser(firstName, firstName);
        
        System.out.print("Enter Your Last Name: ");
        String lastName = scan.nextLine();
        myObj.registerUser(lastName, lastName);
        
        while(true){    //loop until user enters a true value
            System.out.print("Please enter your username: ");
            username = scan.nextLine();
        
            if(myObj.checkUsername(username)){       //calling checkUsername from a login class
                System.out.println("Username successfully captured");
                break;
            }else{    
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.\n");
            }
        }      
        
        while(true){    
            System.out.print("Please enter your password: ");
            password = scan.nextLine();

            if(myObj.checkPasswordComplexity(password)){     //calling checkPassword from a login class
                System.out.println("Password successfully captured.");    //output for a true password
                break;    //when the user has entered the true value, it must break and go to the next task
            }else{
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n");
            }
        }
        
        while(true){    
            System.out.print("Please enter your Cellphone number: ");
            String phone_number = scan.nextLine();

            if(myObj.checkPhoneNumber(phone_number)){       //calling checkPhoneNumber from a login class
                System.out.println("Cellphone number successfully addedd.");    
                break;               
            }else{
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.\n"); //output for a false Cellphone numbers
            }
        }
        
        System.out.println("\n=====User Log in=====");
        
        //it must allow a user to login
        while(true){
            System.out.println("Please enter your username: ");
            String validUsername = scan.nextLine();     //checkUsername must be the same with username

            System.out.println("Please enter your password: ");
            String validPassword = scan.nextLine();    //checkPassword must be the same with password

            if(myObj.userLogin(username, validUsername, password, validPassword)){    //username and password must be the same with the registered username and password
                System.out.println("Welcome " + firstName + ", " + lastName + ", " + "it is great to see you again.");
                break;
            }else{
                System.out.println("Username or password incorrect, please try again\n");
            }
        }
    }
}
